<?php
	//CREATED BY JAKE, Skype RennTekStudios
	// CONNECTIONS =========================================================
	$host = "localhost"; //hostname
	$username = "root"; //database username
	$password = ""; //database password
	$database = ""; //database name
	$table = "";//Database table your using 
?>
